#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 13:30:14 2020

@author: Ronin Gomez
"""

from flask_sqlalchemy import SQLAlchemy

# Initialize the Flask-SQLAlchemy extension instance
db = SQLAlchemy()